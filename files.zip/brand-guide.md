# Jersey HUB brand guide

Mark: JH monogram, the J and H share one stem. Wordmark: custom squared capitals with 45 degree cuts.

Colors
- Pitch: #0a1f16 (tile, dark backgrounds, ink on light)
- Turf: #b6f23a (the mark, buttons and actions only)
- Chalk: #eef5f0 (wordmark on dark)
- Wash: #13302a (top of the page gradient)
- Mist: #9bb5a7 (tagline, secondary text)
- Paper: #f4f1ea (light backgrounds)

Files
- logo.svg: header, dark backgrounds. logo-light.svg: white or paper backgrounds.
- logo-tagline*.svg: large uses only (banners, print, packaging).
- logo-stacked*.svg: square spaces such as posters and tags.
- mark.svg and mark-lime.svg: icon uses. mark-lime.svg is the WhatsApp and social profile picture.
- favicon.svg plus PNG and ICO sizes in png/.

Rules
- Clear space: keep at least the height of the H stem empty on all sides.
- Minimum size: lockup 120 px wide, mark alone 16 px.
- Do not recolor the mark, stretch it, add shadows or glows, or put it on busy photos.
- Turf green is for the mark and actions. Do not use it as body text.
